function checkDiv(div) { //check if element is placed
    'use strict';
     var keys = Object.keys(elements),
          loc = keys.indexOf(div);
     if (loc !== -1){
        return document.getElementById(keys[loc]);
     }
    return;
}

var translate = {
    en: {
        weekday: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        sday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        month: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        smonth: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        condition: ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"]
    },
    dh:{
      weekday: ["އާދީއްތަ", "ހޯމަ", "އަންގާރަ", "ބުދަ", "ބުރާސްފަތި", "ހުކުރު", "ހޮނިހިރު"],
      sday: ["އާދީ", "ހޯ", "އަން", "ބު", "ބުރާ", "ހުކު", "ހޮނި"],
      month: ["ޖަނަވަރީ", "ފެބުރުއަރީ", "މާރިޗް", "އޭޕްރީލް", "މެއި", "ޖޫން", "ޖުލައި", "އޯގަސްޓް", "ސެޕްޓެމްބަރ", "އޮކުޓޯބަރ", "ނޮވެމްބަރ", "ޑިސެމްބަރ"],
      smonth: ["ޖަނަ", "ފެބު", "މާރ", "އޭޕް", "މެއި", "ޖޫން", "ޖުލައި", "އޯގަ", "ސެޕް", "އޮކު", "ނޮވެ", "ޑިސެ"],
        condition: ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"]
    }

};

if(!translate[lang]){
  lang = 'en';
}
function convertTOWord(num){
    var onesText = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'],
        tensText = ['', '', 'twenty', 'thirty', 'fourty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'],
        aboveText = ['', ' thousand ', ' million ', ' billion ', ' trillion ', ' quadrillion ', ' quintillion ', ' sextillion '],
        generatedArray = [],
        converted = '',
        i = 0;
        while(num){
            generatedArray.push( num % 1000 );
            num = parseInt( num / 1000, 10 );
        }
        while (generatedArray.length) {
            converted = (function( a ) {
                var x = Math.floor( a / 100 ),
                    y = Math.floor( a / 10 ) % 10,
                    z = a % 10;
                return ( x > 0 ? onesText[x] + ' hundred ' : '' ) +
                       ( y >= 2 ? tensText[y] + ' ' + onesText[z] : onesText[10*y + z] );
            })( generatedArray.shift() ) + aboveText[i++] + converted;
        }
        return converted;
}
function clock(options) {
    'use strict';
    var getTimes = function () {
            var d = new Date(),
                funcs = {
                    daysInMonth: [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                    hour: function () {
                        var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
                        return hour;
                    },
                    zhour : function () {
                        var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
                        hour = hour < 10 ? "0" + hour : " " + hour;
                        return hour;
                    },
                    rawhour: function () {
                        return d.getHours();
                    },
                    minute: function () {
                        return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
                    },
                    second: function () {
                        return (d.getSeconds() < 10) ? "0" + d.getSeconds() : d.getSeconds();
                    },
                    rawminute: function () {
                        return d.getMinutes();
                    },
                    am: function () {
                        return (d.getHours() > 11) ? "pm" : "am";
                    },
                    tod: function () {
                        return (d.getHours() > 11) ? "Afternoon" : "Morning";
                    },
                    date: function () {
                        return d.getDate();
                    },
                    prevdate: function () {
                        var pd = (this.date() === 0) ? this.daysInMonth[this.month() - 1] : this.date() - 1;
                        return pd;
                    },
                    nextdate: function () {
                        var nd = (this.date() === 0) ? this.daysInMonth[this.month() + 1] : this.date() + 1;
                        return nd;
                    },
                    day: function () {
                        return d.getDay();
                    },
                    month: function () {
                        return d.getMonth();
                    },
                    year: function () {
                        return d.getFullYear();
                    },
                    smyear: function () {
                        return d.getFullYear() % 1000;
                    },
                    hourtext: function () {
                        var hourtxt = (options.twentyfour === true) ? ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four"] : ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
                        return hourtxt[this.rawhour()];
                    },
                    minuteonetext: function () {
                        var minuteone = ["o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
                        if (minuteone[this.rawminute()] !== undefined) {
                            return minuteone[this.rawminute()];
                        }
                        return "";
                    },
                    minuteonetextdot: function () {
                        var minuteone = ["", "one", "o.two", "o.three", "o.four", "o.five", "o.six", "o.seven", "o.eight", "o.nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
                        if (minuteone[this.rawminute()] !== undefined) {
                            return minuteone[this.rawminute()];
                        }
                        return "";
                    },
                    minutetwotext: function () {
                        var minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""];
                        if (minutetwo[this.rawminute()] !== undefined) {
                            return minutetwo[this.rawminute()];
                        }
                        return "";
                    },
                    daytext: function () {
                        return translate[lang].weekday[this.day()];
                    },
                    yesterdaydaytext: function () {
                        return (this.day() === 0) ? translate[lang].weekday[6] : translate[lang].weekday[this.day() - 1];
                    },
                    nextdaytext: function () {
                        return (this.day() === 6) ? translate[lang].weekday[0] : translate[lang].weekday[this.day() + 1];
                    },
                    sdaytext: function () {
                        return translate[lang].sday[this.day()];
                    },
                    snextday: function () {
                        return (this.day() === 6) ? translate[lang].sday[0] : translate[lang].sday[this.day() + 1];
                    },
                    sprevday: function () {
                        return (this.day() === 0) ? translate[lang].sday[6] : translate[lang].sday[this.day() - 1];
                    },
                    monthtext: function () {
                        return translate[lang].month[this.month()];
                    },
                    nextmonthtext: function () {
                        return (this.month() === 11) ? translate[lang].month[0] : translate[lang].month[this.month() + 1];
                    },
                    prevmonthtext: function () {
                        return (this.month() === 0) ? translate[lang].month[11] : translate[lang].month[this.month() - 1];
                    },
                    smonthtext: function () {
                        return translate[lang].smonth[this.month()];
                    },
                    snextmonth: function () {
                        return (this.month() === 11) ? translate[lang].smonth[0] : translate[lang].smonth[this.month() + 1];
                    },
                    sprevmonth: function () {
                        return (this.month() === 0) ? translate[lang].smonth[11] : translate[lang].smonth[this.month() - 1];
                    },
                    datetext: function () {
                        var textdate = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth", "Eleventh", "Twelfth", "Thirteenth", "Fourteenth", "Fifteenth", "Sixteenth", "Seventeenth", "Eightheenth", "Nineteenth", "Twentyith", "TwentyFirst", "TwentySecond", "TwentyThird", 'TwentyFourth', "TwentyFifth", "TwentySixth", "TwentySeventh", "TwentyEight", "TwentyNinth", "Thirtyith", "ThirtyFirst"];
                        return textdate[this.date() - 1];
                    },
                    nth: function (d) {
                        if (d > 3 && d < 21) {
                            return 'th';
                        }
                        switch (d % 10) {
                        case 1:
                            return "st";
                        case 2:
                            return "nd";
                        case 3:
                            return "rd";
                        default:
                            return "th";
                        }
                    },
                    dateplus: function () {
                        return this.date() + this.nth(Number(this.date()));
                    }
                };
            options.success(funcs);
            setTimeout(function () {
                getTimes();
            }, options.refresh);
        };
    getTimes();
}











var globalClock;
function loadClock() { //clock
    clock({
        twentyfour: twentyfour,
        refresh: clockrefresh,
        success: function(clock) {
            'use strict';
            globalClock = clock;
            var clockArray = ['clock', 'zclock', 'clockline', 'clockpm', 'zhour', 'hour', 'minute', 'second', 'pm', 'tod', 'ttext', 'htext', 'mtext', 'date', 'prevdate', 'nextdate', 'dateplus', 'datetext', 'day', 'nextday', 'yestday', 'sday', 'snextday', 'sprevday', 'month', 'nextmonth', 'prevmonth', 'monthstring', 'datedotmonth', 'dateslashmonth', 'datemonth', 'smonth', 'snextmonth', 'sprevmonth', 'monthdot', 'monthline', 'mdy', 'datestring', 'datedash', 'year', 'datemonthrev', 'monthlinespace', 'daydate', 'datestringrev', 'datespace', 'daydotdate','hrmin','hrmintx','daydatemonth', 'daydatesmonth', 'daydatescommamonth', 'yeartext','hrnsmin', 'clocksmush', 'datebar', 'datesnslash', 'datesingled', 'hrsmush', 'dayabdatemonth', 'daycommadatemonth', 'nsmd', 'ndsm', 'ndsmd', 'nsmdd', 'ndatedash','nsmmyear','nmdplusyear','nhrtmin','nhrtarrowmin','nttext'];
            for (var i = 0; i < clockArray.length; i++) {
                var div = checkDiv(clockArray[i]);
                if (div) {
                    var value;
                    switch (div.id) {
                      case 'datemonthrev':
                            value = clock.monthtext() + " " + clock.date();
                            break;
                      case 'monthlinespace':
                            value = clock.monthtext() + " | " + clock.date() + " | " + clock.year();
                            break;
                      case 'daydate':
                            value = clock.daytext() + " " + clock.date();
                            break;
                      case 'datespace':
                            value = clock.daytext() + " " + clock.monthtext() + " " + clock.date();
                            break;
                      case 'daydotdate':
                            value = clock.daytext() + "." + clock.date();
                            break;
                       case 'datestringrev':
                            value = clock.monthtext() + " " + clock.date() + ", " + clock.daytext();
                            break;
                      case 'hrmintx':
                            value = (clock.minutetwotext() !== "") ? clock.hourtext() + '.' + clock.minuteonetextdot() +  '.' + clock.minutetwotext() : clock.hourtext() + '.' + clock.minuteonetextdot() + clock.minutetwotext();
                            break;
                      case 'hrmin':
                            value = clock.hourtext() + '.' + clock.minute();
                            break;
                      case 'daydatemonth':
                            value = clock.daytext() + " | " + clock.date() + " " + clock.monthtext();
                            break;
                        case 'clock':
                            value = clock.hour() + ":" + clock.minute();
                            break;
                        case 'zclock':
                            value = clock.zhour() + ":" + clock.minute();
                            break;
                        case 'clockline':
                            value = clock.hour() + "|" + clock.minute();
                            break;
                        case 'clockpm':
                            value = clock.hour() + ":" + clock.minute() + clock.am();
                            break;
                        case 'zhour':
                            value = clock.zhour();
                            break;
                        case 'hour':
                            value = clock.hour();
                            break;
                        case 'minute':
                            value = clock.minute();
                            break;
                        case 'second':
                            value = clock.second();
                            break;
                        case 'pm':
                            value = clock.am();
                            break;
                        case 'tod':
                            value = clock.tod();
                            break;
                        case 'ttext':
                            value = clock.hourtext() + " " + clock.minuteonetext() + ' ' + clock.minutetwotext();
                            break;
                        case 'htext':
                            value = clock.hourtext();
                            break;
                        case 'mtext':
                            value = clock.minuteonetext() + ' ' + clock.minutetwotext();
                            break;
                        case 'date':
                            value = clock.date();
                            break;
                        case 'prevdate':
                            value = clock.prevdate();
                            break;
                        case 'nextdate':
                            value = clock.nextdate();
                            break;
                        case 'dateplus':
                            value = clock.dateplus();
                            break;
                        case 'datetext':
                            value = clock.datetext();
                            break;
                        case 'day':
                            value = clock.daytext();
                            break;
                        case 'nextday':
                            value = clock.nextdaytext();
                            break;
                        case 'yestday':
                            value = clock.yesterdaydaytext();
                            break;
                        case 'sday':
                            value = clock.sdaytext();
                            break;
                        case 'snextday':
                            value = clock.snextday();
                            break;
                        case 'sprevday':
                            value = clock.sprevday();
                            break;
                        case 'month':
                            value = clock.monthtext();
                            break;
                        case 'nextmonth':
                            value = clock.nextmonthtext();
                            break;
                        case 'prevmonth':
                            value = clock.prevmonthtext();
                            break;
                        case 'monthstring':
                            value = clock.monthtext() + " the " + clock.dateplus();
                            break;
                        case 'datedotmonth':
                            value = clock.date() + '.' + clock.monthtext();
                            break;
                        case 'dateslashmonth':
                            value = clock.date() + "/" + clock.monthtext();
                            break;
                        case 'datemonth':
                            value = clock.date() + " " + clock.monthtext();
                            break;
                        case 'smonth':
                            value = clock.smonthtext();
                            break;
                        case 'snextmonth':
                            value = clock.snextmonth();
                            break;
                        case 'sprevmonth':
                            value = clock.sprevmonth();
                            break;
                        case 'monthdot':
                            value = clock.monthtext() + "." + clock.date();
                            break;
                        case 'monthline':
                            value = clock.monthtext() + "|" + clock.date() + "|" + clock.year();
                            break;
                        case 'mdy':
                            value = (clock.month() + 1) + "/" + clock.date() + "/" + clock.year();
                            break;
                        case 'datestring':
                            value = clock.daytext() + ", " + clock.monthtext() + " " + clock.date();
                            break;
                        case 'datedash':
                            value = clock.daytext() + "-" + clock.monthtext() + "-" + clock.date();
                            break;
                        case 'year':
                            value = clock.year();
                            break;
                        case 'daydatesmonth':
                            value = clock.daytext() + ' ' + clock.date() + ' ' + clock.smonthtext();
                            break;
                        case 'daydatescommamonth':
                            value = clock.daytext() + ', ' + clock.date() + ' ' + clock.smonthtext();
                            break;
                        case 'yeartext':
                            value = convertTOWord(clock.year());
                            break;
                        case 'datebar':
                            value = clock.month() + '|' + clock.date() + '|' + clock.smyear();
                            break;
                        case 'datesnslash':
                            value = clock.month() + '/' + clock.date() + '/' + clock.smyear();
                            break;
                        case 'datesingled':
                            value = clock.month() + '-' + clock.date() + '-' + clock.smyear();
                            break;
                        case 'hrsmush':
                            value = clock.hourtext() + '' + clock.minute();
                            break;
                        case 'dayabdatemonth':
                            value = clock.sdaytext() + ' ' + clock.date() + ' ' + clock.smonthtext();
                            break;
                        case 'daycommadatemonth':
                            value = clock.sdaytext() + ', ' + clock.date() + ' ' + clock.smonthtext();
                            break;
                        case 'hrnsmin':
                            value = clock.hourtext() + ' ' + clock.minute();
                            break;
                        case 'clocksmush':
                            value = clock.hour() + "" + clock.minute();
                            break;
                        case 'nsmd':
                            value = clock.smonthtext() + " " + clock.date();
                            break;
                        case 'ndsm':
                            value = clock.date() + " " + clock.smonthtext();
                            break;
                        case 'ndsmd':
                            value = clock.date() + " " + clock.sdaytext();
                            break;
                        case 'nsmdd':
                            value = clock.sdaytext() + " " + clock.date();
                            break;
                        case 'ndatedash':
                            value = clock.daytext() + " - " + clock.monthtext() + " - " + clock.date();
                            break;
                        case 'nsmmyear':
                            value = clock.smonthtext() + " " + clock.year();
                            break;
                        case 'nmdplusyear':
                            value = clock.monthtext() + " " + clock.dateplus() + " " + clock.year();
                            break;
                        case 'nhrtmin':
                            value = clock.hourtext() + ':' + clock.minute();
                            break;
                        case 'nhrtarrowmin':
                            value = clock.hourtext() + '>>' + clock.minute();
                            break;
                        case 'nttext':
                            value = "[" + clock.hourtext() + "]" + "" + clock.minuteonetext() + '' + clock.minutetwotext();
                            break;

                    }
                      var prefix, suffix;
                      if(div.getAttribute('data-prefix') !== null){
                        prefix = div.getAttribute('data-prefix');
                      }else{
                        prefix = '';
                      }
                      if(div.getAttribute('data-suffix') !== null){
                        suffix = div.getAttribute('data-suffix');
                      }else{
                        suffix = '';
                      }
                      div.innerHTML = prefix + value + suffix;

                }
            };
        }
    });
} //end clock